package br.com.banco.server;

import java.math.BigDecimal;
import java.util.Date;

import br.com.banco.server.OperacaoEnum;

public class Extrato {
    private Integer id;
    private Banco contaOrigem;
    private Banco contaDestino;
    private String operacao;
    private BigDecimal valor;
    private Date dataOcorrencia;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Banco getContaOrigem() {
        return contaOrigem;
    }

    public void setContaOrigem(Banco contaOrigem) {
        this.contaOrigem = contaOrigem;
    }

    public Banco getContaDestino() {
        return contaDestino;
    }

    public void setContaDestino(Banco contaDestino) {
        this.contaDestino = contaDestino;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(OperacaoEnum operacaoEnum) {
        this.operacao = operacaoEnum.getValor();
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public Date getDataOcorrencia() {
        return dataOcorrencia;
    }

    public void setDataOcorrencia(Date dataOcorrencia) {
        this.dataOcorrencia = dataOcorrencia;
    }
}
