package br.com.banco.server;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import br.com.banco.server.Banco;
import br.com.banco.server.Extrato;
import br.com.banco.server.OperacaoEnum;
import br.com.banco.server.SqlBuilder;

public class ExtratoRepository extends AbstractRepository{
    public ResultSet create(OperacaoEnum operacao, Integer idConta, BigDecimal valor) {
    	String sql = new SqlBuilder
                .Insert("extrato")
                .column("conta_origem", idConta.toString())
                .column("tipo", operacao.toString())
                .column("valor", valor.toString())
                .column("data", new Date().toString())
                .buildString();

        return executeQuery(sql);
    }

    public ResultSet create(OperacaoEnum operacao, Integer idContaOrigem, Integer idContaDestino, BigDecimal valor) {
        String sql = new SqlBuilder
                .Insert("extrato")
                .column("conta_origem", idContaOrigem.toString())
                .column("conta_destino", idContaDestino.toString())
                .column("tipo", operacao.toString())
                .column("valor", valor.toString())
                .column("data", new Date().toString())
                .buildString();

        return executeQuery(sql);
    }

    public List<Extrato> findAll(Banco conta) {
        List<Extrato> transacoes = new ArrayList<Extrato>();
        Extrato transacao = null;
        BancoRepository contaOrigem = new BancoRepository();
        BancoRepository contaDestino = new BancoRepository();

        String sql = new SqlBuilder
                .Select("*")
                .from("extrato")
                .where("conta_origem", "=", conta.getId())
                .buildString();
        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                transacao = new Extrato();
                transacao.setId(rs.getInt("id"));
                transacao.setContaOrigem(contaOrigem.findById(rs.getInt("conta_origem")));
                transacao.setContaDestino(contaDestino.findById(rs.getInt("conta_destino")));
                transacao.setOperacao(OperacaoEnum.valueOf(rs.getString("tipo")));
                transacao.setValor(rs.getBigDecimal("valor"));
                transacao.setDataOcorrencia(rs.getDate("data"));
                transacoes.add(transacao);
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return transacoes;
    }

    public List<Extrato> findAll(Banco conta, Date periodoInicial, Date periodoFinal) {
        List<Extrato> transacoes = new ArrayList<Extrato>();
        Extrato transacao = null;
        BancoRepository contaOrigem = new BancoRepository();
        BancoRepository contaDestino = new BancoRepository();

        String sql = new SqlBuilder
                .Select("*")
                .from("extrato")
                .where("conta_origem", "=", conta.getId())
                .where("data", ">=", periodoInicial.toString())
                .where("data", "<=", periodoFinal.toString())
                .buildString();
        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                transacao = new Extrato();
                transacao.setId(rs.getInt("id"));
                transacao.setContaOrigem(contaOrigem.findById(rs.getInt("conta_origem")));
                transacao.setContaDestino(contaDestino.findById(rs.getInt("conta_destino")));
                transacao.setOperacao(OperacaoEnum.valueOf(rs.getString("tipo")));
                transacao.setValor(rs.getBigDecimal("valor"));
                transacao.setDataOcorrencia(rs.getDate("data"));
                transacoes.add(transacao);
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return transacoes;
    }
}