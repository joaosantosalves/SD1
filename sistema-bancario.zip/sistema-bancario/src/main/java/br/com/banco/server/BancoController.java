package br.com.banco.server;

import org.apache.commons.codec.digest.DigestUtils;

import br.com.banco.server.Banco;
import br.com.banco.server.BancoInterface;
import br.com.banco.server.BancoService;
import br.com.banco.server.Cadastro;
import br.com.banco.server.CadastroService;
import br.com.banco.server.Extrato;
import br.com.banco.server.ExtratoService;

import java.math.BigDecimal;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public class BancoController extends UnicastRemoteObject implements BancoInterface {

	private static final long serialVersionUID = -1400220616929807673L;

	protected BancoController() throws RemoteException {
    }

    @Override
    public Integer criarCadastro(String nome, String cpf, String telefone, Date dtNascimento) throws RemoteException {
        Cadastro cliente = new Cadastro();
        cliente.setNome(nome);
        cliente.setCpf(cpf);
        cliente.setTelefone(telefone);
        cliente.setDataNascimento(dtNascimento);

        return CadastroService.createAndGetId(cliente);
    }

    @Override
    public Integer criarCliente(String cpf, String senha) throws RemoteException {
        Cadastro cliente = CadastroService.buscarCadastro(cpf);
        return BancoService.createAndGetId(cliente, senha);
    }

    @Override
    public Boolean acessarCliente(Integer idConta, String senha) throws RemoteException {
        Banco conta = BancoService.buscarContaPorId(idConta);
        String senhaCriptografada = DigestUtils.md5Hex(senha).toUpperCase();
        return senhaCriptografada.equals(conta.getSenha());
    }

    @Override
    public BigDecimal consultaSaldo(Integer idConta) throws RemoteException {
        return BancoService.consultaSaldo(idConta);
    }

    @Override
    public void saque(Integer idConta, BigDecimal valor) throws RemoteException {
        BancoService.sacar(idConta, valor);
    }

    @Override
    public void deposito(Integer idConta, BigDecimal valor) throws RemoteException {
        BancoService.depositar(idConta, valor);
    }

    @Override
    public void transferencia(Integer idConta, String cpfDestino, BigDecimal valor) throws RemoteException {
        Cadastro cliente = CadastroService.buscarCadastro(cpfDestino);
        Banco contaDestino = BancoService.buscarBanco(cliente.getId());

        BancoService.transferir(idConta, contaDestino.getCliente().getId(), valor);
    }

    @Override
    public List<HashMap<String, String>> consultaExtrato(Integer idConta) throws RemoteException {
        ArrayList<Extrato> transacoes = (ArrayList<Extrato>) ExtratoService.consultaExtrato(idConta);
        return getExtratoFromTransacoes(transacoes);
    }

    @Override
    public List<HashMap<String, String>> consultaExtratoPeriodo(Integer idConta, Date periodoInicial, Date periodoFinal) throws RemoteException {
        ArrayList<Extrato> transacoes = (ArrayList<Extrato>) ExtratoService.consultaExtratoPeriodo(idConta, periodoInicial, periodoFinal);
        return getExtratoFromTransacoes(transacoes);
    }

    private List<HashMap<String, String>> getExtratoFromTransacoes(ArrayList<Extrato> transacoes) {
        List<HashMap<String, String>> extrato = new ArrayList<>();

        for (Extrato transacao : transacoes) {
            HashMap<String, String> dadoTransacao = new HashMap<>();
            dadoTransacao.put("CONTA", transacao.getContaOrigem().getId().toString());
            if (transacao.getContaDestino().getId() != null) {
                dadoTransacao.put("CONTA_DESTINO", transacao.getContaDestino().getId().toString());
            }
            dadoTransacao.put("TIPO", transacao.getOperacao());
            dadoTransacao.put("VALOR", transacao.getValor().toString());
            dadoTransacao.put("DATA", transacao.getDataOcorrencia().toString());

            extrato.add(dadoTransacao);
        }
        return extrato;
    }

    public static void main(String[] args) {
        try {
            BancoController obj = new BancoController();
            Registry registry = LocateRegistry.createRegistry(2001);
            registry.rebind("BancoServer", obj);
            System.out.println("Servidor carregado no registry");
        } catch (Exception e) {
            System.out.println("Banco RMI erro: " + e.getMessage());
        }
    }
}
