package br.com.banco.server;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.banco.server.Cadastro;
import br.com.banco.server.CadastroRepository;

public class CadastroService {

    private static final CadastroRepository clienteRepository = new CadastroRepository();

    public static Integer createAndGetId(Cadastro cliente) {
        ResultSet resultSet = clienteRepository.create(cliente);

        try {
            if (resultSet.next()) {
                return resultSet.getInt(1); //retorna o id
            }
        } catch (SQLException ignored) {
        }

        return null;
    }

    public static Cadastro buscarCadastro(String cpf) {
        return clienteRepository.find(cpf); //procura o cadastro pelo cpf
    }
}
