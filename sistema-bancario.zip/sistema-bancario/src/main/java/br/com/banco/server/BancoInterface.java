package br.com.banco.server;

import java.math.BigDecimal;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

public interface BancoInterface extends Remote {

    Integer criarCadastro(String nome, String cpf, String telefone, Date dtNascimento) throws RemoteException;

    Integer criarCliente(String cpf, String senha) throws RemoteException;

    Boolean acessarCliente(Integer idConta, String senha) throws RemoteException;

    BigDecimal consultaSaldo(Integer idConta) throws RemoteException;

    void saque(Integer idCliente, BigDecimal valor) throws RemoteException;

    void deposito(Integer idCliente, BigDecimal valor) throws RemoteException;

    void transferencia(Integer idCliente, String cpfDestino, BigDecimal valor) throws RemoteException;

    List<HashMap<String, String>> consultaExtrato(Integer idCliente) throws RemoteException;

    List<HashMap<String, String>> consultaExtratoPeriodo(Integer idCliente, Date periodoInicial, Date periodoFinal) throws RemoteException;

}
