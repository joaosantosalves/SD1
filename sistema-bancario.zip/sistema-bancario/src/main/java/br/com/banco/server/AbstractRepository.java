package br.com.banco.server;

import java.sql.*;

import br.com.banco.server.ConexaoFactory;

public abstract class AbstractRepository {

    protected ResultSet executeQuery(String sql) {
    	Connection conexao = null;
        PreparedStatement ps;

        try {
            conexao = ConexaoFactory.createConnection();
            conexao.setAutoCommit(false); //desativa o autocommit

            if (sql.startsWith("SELECT")) {
                ps = conexao.prepareStatement(sql); //
                ps.executeQuery(); //
            } else {
                String[] columnNames = new String[]{"id"}; //adiciona a coluna id no insert
                ps = conexao.prepareStatement(sql, columnNames);
                ps.executeUpdate();
            }

            conexao.commit();

            if (sql.startsWith("SELECT")) {
                return ps.getResultSet(); //retorna o resultset
            } else {
                return ps.getGeneratedKeys(); //retorna o id gerado pelo banco de dados
            }
          
            
        } catch (SQLException e) {
            if (conexao != null) {
                try {
                    System.err.print("Rollback efetuado na transação.");
                    conexao.rollback(); //volta para o estado inicial antes da desativação do autocommit
                } catch(SQLException e2) {
                    System.err.print("SQLException: " + e2);
                }
            } else {
                System.err.print("SQLException: " + e);
            }
        } finally {
            try {
                if (conexao != null) {
                    conexao.setAutoCommit(true);
                }
            }  catch (SQLException e) {
                System.err.print("SQLException: " + e);
            }
        }

        return null;
    }
}
