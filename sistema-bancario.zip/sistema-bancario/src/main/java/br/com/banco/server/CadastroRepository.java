package br.com.banco.server;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.banco.server.Cadastro;
import br.com.banco.server.SqlBuilder;

public class CadastroRepository extends AbstractRepository {

    public ResultSet create(Cadastro cliente) {
        String sql = new SqlBuilder
                .Insert("cadastro")
                .column("nome", cliente.getNome())
                .column("cpf", cliente.getCpf())
                .column("telefone", cliente.getTelefone())
                .column("data_nascimento", cliente.getDataNascimento().toString())
                .buildString();

        return executeQuery(sql);
    }

    public ResultSet update(Integer id, Cadastro cliente) {
        SqlBuilder.Update updateBuilder = new SqlBuilder.Update("cliente");

        if (cliente.getNome() != null) {
            updateBuilder.set("nome", cliente.getNome());
        }

        if (cliente.getCpf() != null) {
            updateBuilder.set("cpf", cliente.getCpf());
        }

        if (cliente.getTelefone() != null) {
            updateBuilder.set("telefone", cliente.getTelefone());
        }

        if (cliente.getDataNascimento() != null) {
            updateBuilder.set("data_nascimento", cliente.getDataNascimento().toString());
        }

        String sql = updateBuilder
                .where("id", "=", id)
                .buildString();

        return executeQuery(sql);
    }

    public Cadastro findById(Integer id) {
        Cadastro cliente = new Cadastro();
        String sql = new SqlBuilder
                .Select("*")
                .from("cadastro")
                .where("id", "=", id)
                .buildString();

        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setDataNascimento(rs.getDate("data_nascimento"));
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return cliente;
    }

    public Cadastro find(String cpf) {
        Cadastro cliente = new Cadastro();
        String sql = new SqlBuilder
                .Select("*")
                .from("cadastro")
                .where("cpf", "=", cpf)
                .buildString();

        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                cliente.setId(rs.getInt("id"));
                cliente.setNome(rs.getString("nome"));
                cliente.setCpf(rs.getString("cpf"));
                cliente.setTelefone(rs.getString("telefone"));
                cliente.setDataNascimento(rs.getDate("data_nascimento"));
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return cliente;
    }

    public void delete(Integer id) {
        String sql = new SqlBuilder
                .Delete()
                .from("cadastro")
                .where("id", "=", id)
                .buildString();

        executeQuery(sql);
    }
}
