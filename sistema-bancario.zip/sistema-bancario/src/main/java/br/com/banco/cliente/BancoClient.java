package br.com.banco.cliente;

import java.math.BigDecimal;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import br.com.banco.server.BancoInterface;

public class BancoClient {
	static Scanner in = new Scanner(System.in);

    @SuppressWarnings("deprecation")
	public static void main(String[] args) throws IllegalAccessException, RemoteException, NotBoundException {
        BancoInterface obj;

        try {
            obj = getBancoInterface(args);

            obj.criarCadastro("João", "11345678916", "5563981918191", new Date("10/05/1993"));

            Integer idConta = obj.criarCliente("11345678916", "123456");
            if (obj.acessarCliente(idConta, "123456")) {
                obj.deposito(idConta, new BigDecimal(75));
                obj.saque(idConta, new BigDecimal(50));
            }

            List<HashMap<String, String>> extrato = obj.consultaExtrato(idConta);
            for (int i = 0; i < extrato.size(); i++) {
                System.out.println(extrato.get(i));
            }

            obj.criarCadastro("Guilherme", "11343378916", "5563941918191", new Date());
            Integer idContaGuilherme = obj.criarCliente("11343378916", "123");
            if (obj.acessarCliente(idContaGuilherme, "123")) {
            	obj.transferencia(idConta, "11343378916", new BigDecimal(20));
            }
        }
        catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
        }
        
    }
    private static BancoInterface getBancoInterface(String[] ids) throws RemoteException, NotBoundException {
        int randomIndex = (int) Math.round(Math.random() * (ids.length - 1));
        Registry registry = LocateRegistry.getRegistry(ids[randomIndex], 2001);
        return (BancoInterface) registry.lookup("BancoServer");
    }
}
