package br.com.banco.cliente;

import java.math.BigDecimal;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

import br.com.banco.server.BancoInterface;

public class BancoClient {
	static Scanner in = new Scanner(System.in);

    @SuppressWarnings("deprecation")
	public static void main(String[] args) throws IllegalAccessException, RemoteException, NotBoundException {
        BancoInterface obj;

        try {
            obj = getBancoInterface(args);

            obj.criarCadastro("João", "11345678915", "5563981918191", new Date("10/05/1993"));

            Integer idConta = obj.criarCliente("11345678915", "123456");
            if (obj.acessarCliente(idConta, "123456")) {
                obj.deposito(idConta, new BigDecimal(75));
                obj.saque(idConta, new BigDecimal(50));
            }

            List<HashMap<String, String>> extrato = obj.consultaExtrato(idConta);
            for (int i = 0; i < extrato.size(); i++) {
                System.out.println(extrato.get(i));
            }

            obj.criarCadastro("Guilherme", "11343378915", "5563941918191", new Date());
            Integer idContaGuilherme = obj.criarCliente("11343378915", "123");
            if (obj.acessarCliente(idContaGuilherme, "123")) {
            	obj.transferencia(idConta, "11343378915", new BigDecimal(20));
            }
        }
        catch (Exception e) {
            System.out.println("Client exception: " + e.getMessage());
        }
        
        /*obj = getBancoInterface(args);
        
        boolean loggedIn = false;
		int idConta;
		String senha = "123456";
		
		
		do {
			
		System.out.println("\n\n   *** Bem vindo ao AssisBank ***   ");

		System.out.println("\nDidite o usuário e a senha: ");
		System.out.println("\nUsuário: ");
		idConta = in.nextInt();
		System.out.println("Senha: ");
		senha = "123456";

		try {
			if (obj.acessarCliente(idConta, senha)) {
				loggedIn = true;
				
				System.out.println("Login efetuado com sucesso!");
			} else {
				System.out.println("Usuário e/ou senhas incorretas");
				
			}
	
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Erro: Informações incorretas");
		}

		}while(!loggedIn);
		
		while (loggedIn) { 

			System.out.println("\n\n   *** HOME ***   ");
			System.out.println("\nSeu saldo atual: R$" + obj.consultaSaldo(idConta));
			System.out.println("\nDigite uma opção: \n" + "1) Deposito\n" + "2) Saque\n" + "3) Extrato\n" + "4) Sair\n\n" + 
			"[exclusivo funcionarios]\n5) Cadastrar Cliente\n");
			
			int operation = in.nextInt();

			switch (operation) {

			case 1:
				System.out.println("Digite o valor a ser depositado: ");
				Double input = in.nextDouble();
				try {
					obj.deposito(idConta, new BigDecimal(input));
					System.out.println("Depósito efetivado: R$" + input + "\nNovo Saldo: R$" + obj.consultaSaldo(idConta));
				} catch (NumberFormatException e) {
					System.out.println("Valor inválido. Tente novamemte.");
					break;
				}
				break;

			case 2:
				System.out.println("Digite o valor a ser sacado: R$");
				input = in.nextDouble();
				try {
					obj.saque(idConta, new BigDecimal(input));
					System.out.println(
							"Saque efetuado com sucesso: R$" + input + "\nNovo Saldo: R$" + obj.consultaSaldo(idConta));
				} catch (NumberFormatException e) {
					System.out.println("Valor inválido. Tente novamemte");
					break;
				}
				break;

			case 3:
				System.out.println("Extrato: ");
				List<HashMap<String, String>> extrato = obj.consultaExtrato(idConta);
	            for (int i = 0; i < extrato.size(); i++) {
	                System.out.println(extrato.get(i));
	            }
				break;

			case 4:
				System.out.println("Tenha um bom dia!");
				System.exit(0);
				break;
				
			/*case 5:
				try {
					if (bank.checkFuncionario(usuario, senha)) {

						System.out.println("Digite os dados do cliente: ");
						bank.insertNewAccount();

					} else {
						System.out.println("Somente funcionarios podem efetuar cadastros.");
					}
			
				} catch (ArrayIndexOutOfBoundsException e) {
					System.out.println("Erro: Informações incorretas");
				}
				
				break;
				
			default:
				System.out.println("Digito não reconhecido, tente novamente.");
				break;
			}
		}*/
    }
    private static BancoInterface getBancoInterface(String[] ids) throws RemoteException, NotBoundException {
        int randomIndex = (int) Math.round(Math.random() * (ids.length - 1));
        Registry registry = LocateRegistry.getRegistry(ids[randomIndex], 2001);
        return (BancoInterface) registry.lookup("BancoServer");
    }
}
