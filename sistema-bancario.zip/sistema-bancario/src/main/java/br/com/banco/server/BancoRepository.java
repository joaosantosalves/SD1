package br.com.banco.server;

import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.banco.server.Banco;
import br.com.banco.server.SqlBuilder;

public class BancoRepository extends AbstractRepository {

    public ResultSet create(Banco conta) {
        String sql = new SqlBuilder
                .Insert("banco")
                .column("cadastro_id", conta.getCliente().getId().toString())
                .column("senha", conta.getSenha())
                .buildString();

        return executeQuery(sql);
    }

    public Banco findById(Integer id) {
        Banco conta = new Banco();
        CadastroRepository cadastroRepository = new CadastroRepository();
        String sql = new SqlBuilder
                .Select("*")
                .from("banco")
                .where("id", "=", id)
                .buildString();

        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                conta.setId(rs.getInt("id"));
                conta.setCliente(cadastroRepository.findById(rs.getInt("cadastro_id")));
                conta.setSaldo(rs.getBigDecimal("saldo"));
                conta.setSenha(rs.getString("senha"));
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return conta;
    }

    public Banco findByClienteId(Integer idCliente) {
        Banco conta = new Banco();
        CadastroRepository cadastroRepository = new CadastroRepository();
        String sql = new SqlBuilder
                .Select("*")
                .from("banco")
                .where("cadastro_id", "=", idCliente)
                .buildString();

        ResultSet rs = executeQuery(sql);

        try {
            while (rs.next()) {
                conta.setId(rs.getInt("id"));
                conta.setCliente(cadastroRepository.findById(rs.getInt("cadastro_id")));
                conta.setSaldo(rs.getBigDecimal("saldo"));
            }
        } catch (SQLException e) {
            System.out.println("ERRO: " + e.getMessage());
        }

        return conta;
    }

    public ResultSet update(Integer id, Banco conta) {
        SqlBuilder.Update updateBuilder = new SqlBuilder.Update("banco");

        if (conta.getId() != null) {
            updateBuilder.set("id", conta.getId().toString());
        }

        if (conta.getCliente() != null) {
            updateBuilder.set("cadastro_id", conta.getCliente().getId().toString());
        }

        if (conta.getSaldo() != null) {
            updateBuilder.set("saldo", conta.getSaldo().toString());
        }

        if (conta.getSenha() != null) {
            updateBuilder.set("senha", conta.getSenha());
        }

        String sql = updateBuilder
                .where("id", "=", id)
                .buildString();

        return executeQuery(sql);
    }
}