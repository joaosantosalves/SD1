package br.com.banco.server;

import java.util.Date;
import java.util.List;

import br.com.banco.server.BancoRepository;
import br.com.banco.server.Extrato;
import br.com.banco.server.ExtratoRepository;

public class ExtratoService {

    private static final ExtratoRepository transacaoRepository = new ExtratoRepository();
    private static final BancoRepository contaRepository = new BancoRepository();

    public static List<Extrato> consultaExtrato(Integer idConta) {
        return transacaoRepository.findAll(contaRepository.findById(idConta));
    }

    public static List<Extrato> consultaExtratoPeriodo(Integer idConta, Date periodoInicial, Date periodoFinal) {
        return transacaoRepository.findAll(contaRepository.findById(idConta), periodoInicial, periodoFinal);
    }
}
