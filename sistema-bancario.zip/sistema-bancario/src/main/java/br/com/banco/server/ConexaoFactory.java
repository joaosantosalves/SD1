package br.com.banco.server;

import java.sql.*;

public class ConexaoFactory {

    public static Connection createConnection() throws SQLException{
        String url = "jdbc:postgresql://localhost/banco";
        String user = "postgres";
        String password = "postgres";

        return DriverManager.getConnection(url, user, password);
    }
}
