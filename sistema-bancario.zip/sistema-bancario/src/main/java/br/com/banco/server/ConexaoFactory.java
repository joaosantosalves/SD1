package br.com.banco.server;

import java.sql.*;

public class ConexaoFactory {

    public static Connection createConnection() throws SQLException{
        String url = "jdbc:postgresql://172.16.56.190/postgres";
        String user = "postgres";
        String password = "123456";

        return DriverManager.getConnection(url, user, password);
    }
}
