package br.com.banco.server;


import org.apache.commons.codec.digest.DigestUtils;

import br.com.banco.server.Banco;
import br.com.banco.server.BancoRepository;
import br.com.banco.server.Cadastro;
import br.com.banco.server.ExtratoRepository;
import br.com.banco.server.OperacaoEnum;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class BancoService {

    private static final BancoRepository contaRepository = new BancoRepository();
    private static final ExtratoRepository transacaoRepository = new ExtratoRepository();

    public static Integer createAndGetId(Cadastro cliente, String senha) {
        Banco conta = new Banco();
        conta.setCliente(cliente);
        conta.setSenha(criptografarSenha(senha));

        ResultSet resultSet = contaRepository.create(conta);

        try {
            if (resultSet.next()) {
                return resultSet.getInt(1);
            }
        } catch (SQLException ignored) {
        }

        return null;
    }

    public static void sacar(Integer idConta, BigDecimal valor) {
        Banco conta = contaRepository.findById(idConta);
        conta.sacar(valor);

        contaRepository.update(idConta, conta);
        transacaoRepository.create(OperacaoEnum.SAQUE, idConta, valor);
    }

    public static void depositar(Integer idConta, BigDecimal valor) {
        Banco conta = contaRepository.findById(idConta);
        conta.depositar(valor);

        contaRepository.update(idConta, conta);
        transacaoRepository.create(OperacaoEnum.DESPOSITO, idConta, valor);
    }

    public static void transferir(Integer idContaOrigem, Integer idContaDestino, BigDecimal valor) {
        Banco contaOrigem = contaRepository.findById(idContaOrigem);
        Banco contaDestino = contaRepository.findById(idContaDestino);

        contaOrigem.sacar(valor);
        contaDestino.depositar(valor);

        contaRepository.update(idContaOrigem, contaOrigem);
        contaRepository.update(idContaDestino, contaDestino);

        transacaoRepository.create(OperacaoEnum.TRANSFERENCIA, idContaOrigem, idContaDestino, valor);

    }

    public static BigDecimal consultaSaldo(Integer idConta) {
        Banco conta = contaRepository.findById(idConta);
        return (BigDecimal) Optional.ofNullable(conta).map(Banco::getSaldo).orElse(null);
    }

    public static Banco buscarBanco(Integer idCliente) {
        return contaRepository.findByClienteId(idCliente);
    }

    public static Banco buscarContaPorId(Integer idConta) {
        return contaRepository.findById(idConta);
    }

    private static String criptografarSenha(String senha) {
        return DigestUtils.md5Hex(senha).toUpperCase();
    }
}